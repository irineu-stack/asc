describe('template spec', () => {
  it('passes', async function () {
    cy.visit('http://localhost');

    // cy.get('cpf')
    cy.get('input[name=cpf]').type('12312312300')
    cy.get('input[name=password]').type('senai')

    cy.get('input.submit').click()

    cy.get("#origem").type("Guarulhos, GRU - Brasil")
    cy.get("#destino").type("San Pedro, ROS - Argentina")
    cy.get("#ida").type("20/11/2024")

    cy.get(".search .submit").click()



    cy.get(".item").click()

    cy.wait(1000)
    cy.get(".seat div[class='s']").eq(0).click();


    cy.get(".payment-end").click();

    cy.get(".tickets-list .item").eq(0).click();
    
    cy.get(".ticket-checkin").click();
    await cy.wait(10)
    cy.get(".ticket-edit").click(); 


    cy.get(".box-edit #data").type("30/11/2024")
    cy.get(".box-edit .buscar").click();
    await cy.wait(10)
    cy.get(".box-edit .item").click();
    await cy.wait(10)
    cy.get(".seat-table-edit div[class=s]").eq(0).click();

    
    
  })
})






var voo = {
    "origem": "Cacheuta Spa, MDZ - Argentina",
    "destino": "Cacheuta Spa, MDZ - Argentina",
    "start": "09:45",
    "end": "16:45",
    "id": "LA158",
    "assento": "A1",
    "ida": "01/01/2001"
}


// tela de login 
fetch('/getUser')
    .then(response => response.json())
    .then(function (res) {
        if (res.success == false) {
            document.querySelector(".login").style.display = "block"
        } else {
            document.querySelector(".search").style.display = "block"
        }

        window.user = res
    })




document.querySelector("#origem").addEventListener("keypress", function () {
    fetch('/search/' + encodeURIComponent(this.value))
        .then(response => response.json())
        .then(function (res) {
            document.querySelector(".origem-autocomplete-list").innerHTML = ""
            res.forEach(function (i) {
                var div = document.createElement("div")
                div.className = "item"
                div.innerHTML = "<span>" + i.city + ", " + i.iata + " - " + i.country + "</span>"
                div.onclick = function () {
                    document.querySelector("#origem").value = i.city + ", " + i.iata + " - " + i.country
                    document.querySelector("#destino").focus()
                    document.querySelector(".origem-autocomplete-list").innerHTML = ""
                }

                document.querySelector(".origem-autocomplete-list").append(div)
            })
        })
})



document.querySelector("#destino").addEventListener("keypress", function () {
    fetch('/search/' + encodeURIComponent(this.value))
        .then(response => response.json())
        .then(function (res) {
            document.querySelector(".destino-autocomplete-list").innerHTML = ""
            res.forEach(function (i) {
                var div = document.createElement("div")
                div.className = "item"
                div.innerHTML = "<span>" + i.city + ", " + i.iata + " - " + i.country + "</span>"
                div.onclick = function () {
                    document.querySelector("#destino").value = i.city + ", " + i.iata + " - " + i.country
                    document.querySelector("#ida").focus()
                    document.querySelector(".destino-autocomplete-list").innerHTML = ""
                }

                document.querySelector(".destino-autocomplete-list").append(div)
            })
        })
})




document.querySelector(".search .submit").onclick = function () {
    fetch('/findVoo/' + encodeURIComponent(document.querySelector("#origem").value) + "/" + encodeURIComponent(document.querySelector("#destino").value) + "/" + encodeURIComponent(document.querySelector("#ida").value))
        .then(response => response.json())
        .then(function (res) {

            document.querySelector(".search-result").innerHTML = ""


            res.forEach(function (i) {

                console.log(i)
                var div = document.createElement("div")
                div.className = "item"
                div.innerHTML = `
                <span class="time-start">${i.start}</span>
                <span class="time-end">${i.end}</span>
                <span class="duration">
                    <hr>
                    <b>Duração</b>
                    ${i.duration}
                    <hr class="after">
                    </span>
                <span class="price">
                    <b>Tarifa a partir de:</b>
                    BRL ${i.price}
                </span>
            `;
                div.onclick = function () {
                    voo.origem = document.querySelector("#origem").value
                    voo.destino = document.querySelector("#destino").value
                    voo.start = i.start
                    voo.end = i.end
                    voo.id = i.id
                    voo.ida = document.querySelector("#ida").value

                    console.log(voo)
                    getAssentos(i.id)

                }

                document.querySelector(".search-result").append(div)
            })
        })
}







function clearLayout() {
    document.querySelectorAll(".layout").forEach(function (el) {
        el.style.display = "none"
    })
}



function gerarAssentos(seat, size, availables, id, currentSeat, fn) {
    seat.innerHTML = "";


    for (let col = 0; col < 6; col++) {
        for (let row = 0; row < 12; row++) {
            var s = document.createElement("div")
            s.className = "s"



            s.style.left = (col >= 3 ? 50 : 0) + col * size + "px"
            s.style.top = row * size + "px"
            s.style.fontSize = parseInt(size / 2) + "px"
            s.style.width = s.style.height = s.style.lineHeight = parseInt(size * .8) + "px"

            s.innerText = ["A", "B", "C", "D", "E", "F"][col] + row

            if (currentSeat == s.innerText) s.className += " current unavailable"

            if (!availables[s.innerText]) s.className += " unavailable"

            s.onclick = function () {
                if (this.className.indexOf("unavailable") != -1) return;

                voo.assento = this.innerText
                fn(this.innerText);
            }

            seat.append(s)
        }
    }
}


function pagamento() {
    clearLayout()
    document.querySelector(".pagamento").style.display = "block"
}


function swClear() {
    document.querySelector(".card").classList.remove("selected")
    document.querySelector(".pix").classList.remove("selected")
    document.querySelector(".boleto").classList.remove("selected")

    document.querySelector(".card-container").style.display = "none"
    document.querySelector(".pix-container").style.display = "none"
    document.querySelector(".boleto-container").style.display = "none"
}
document.querySelector(".card").onclick = function () {
    swClear()
    document.querySelector(".card").className += " selected"
    document.querySelector(".card-container").style.display = "block"
}
document.querySelector(".pix").onclick = function () {
    swClear()

    fetch('/getPix')
        .then(response => response.json())
        .then(function (res) {
            swClear()

            document.querySelector(".pix").className += " selected"

            document.querySelector(".pix-qrcode").src = res.url
            document.querySelector(".pix-container").style.display = "block"
        })

}
document.querySelector(".boleto").onclick = function () {
    swClear()

    fetch('/getBoleto')
        .then(response => response.json())
        .then(function (res) {
            swClear()
            document.querySelector(".boleto").className += " selected"

            document.querySelector(".boleto-code").src = res.url
            document.querySelector(".boleto-container").style.display = "block"
        })
}



document.querySelector(".payment-end").onclick = function () {
    var payType = document.querySelector(".selected").className.split(" ")[0]
    voo.payType = payType


    fetch('/finish/' + encodeURIComponent(voo.id), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ...voo, ...window.user })
    })
        .then(response => response.json())
        .then(function (res) {
            console.log(res)
            tickets()
        })

    console.log(window.user)
}


function ticketInfo(id) {
    fetch('/getTicket/' + encodeURIComponent(id))
        .then(response => response.json())
        .then(function (res) {
            clearLayout()
            document.querySelector(".ticket-info").style.display = "block"


            // <div class="data"><b>Embarque</b>Sex, 14 jan 2024</div>
            // <div class="nome"><b>Passageiro: </b>Denilson Costa Oliveira</div>
            // <div class="assento"><b>Assento: </b>1A</div>
            // <div class="aeronave"><b>Aeronave: </b>airbus a320</div>



            document.querySelector(".cod-reserva").innerHTML = "Cód. reserva <b>" + res.ticketId + "</b>"
            document.querySelector(".origem").innerHTML = res.origem.replace(/([A-Z][A-Z][A-Z])/, "<b>$1</b>").replace(", ", "").replace("- ", "")
            document.querySelector(".destino").innerHTML = res.destino.replace(/([A-Z][A-Z][A-Z])/, "<b>$1</b>").replace(", ", "").replace("- ", "")

            document.querySelector(".data").innerHTML = "<b>Embarque</b>" + res.start
            document.querySelector(".nome").innerHTML = "<b>Passageiro: </b>" + res.nome
            document.querySelector(".assento").innerHTML = "<b>Assento: </b>" + res.assento
            document.querySelector(".aeronave").innerHTML = "<b>Aeronave: </b>" + res.aeronave

            console.log(res, "asc")
            document.querySelector(".cartao-nome").innerHTML = res.nome + '<p class="cartao-res">#' + res.ticketId + '</p>';


            document.querySelector(".ticket-edit").onclick = function () {
                editTicket(res)
            }

            document.querySelector(".ticket-cancel").onclick = function () {
                fetch('/cancelTicket/' + encodeURIComponent(res.ticketId))
                    .then(response => response.json())
                    .then(function (res) {
                        console.log(res)
                        tickets()
                    })
            }

            if (res.status == "ok") {
                document.querySelector(".checkin-status").innerText = "Voçe ainda não fez Check-in do seu voo, clique em Confirmar Check-in.";
                document.querySelector(".ticket-checkin").innerText = "Confirmar Check-in"
                document.querySelector(".ticket-checkin").onclick = function () {
                    fetch('/checkin/' + encodeURIComponent(res.ticketId))
                        .then(response => response.json())
                        .then(function (res) {
                            console.log(res)

                            document.querySelector(".checkin-status").style.display = "none"
                            document.querySelector(".ticket-checkin").style.display = "none"
                        })
                }

            } else if (res.status == "pay") {
                document.querySelector(".checkin-status").innerText = "O Check-in do seu voo esta indisponível, verifique o pagamento.";
                document.querySelector(".ticket-checkin").innerText = "Segunda via"
                document.querySelector(".ticket-checkin").onclick = function () {
                    window.open("/segundavia")
                }

            } else if (res.status == "confirmed") {
                document.querySelector(".ticket-checkin").style.display = "none"
                document.querySelector(".checkin-status").style.display = "none"
            }

        })
}

function tickets() {
    clearLayout()
    document.querySelector(".tickets").style.display = "block"

    document.querySelector(".tickets-list").innerHTML = ""
    fetch('/getTickets')
        .then(response => response.json())
        .then(function (res) {
            res.forEach(function (i) {
                console.log(i)

                var div = document.createElement("div")
                div.className = "item"
                div.innerHTML = `
                    <div class="item-top">
                        <span class="voo-number">${i.id}</span>
                        <span class="voo-status ${i.status}">${i.cod}</span>
                    </div>
                    <span class="ida">${i.ida}</span>
                    <span class="nome">${i.destino}</span>
                    <span class="start"><b>Enbarque estimado</b><span class="time">${i.start}</span></span>
                    <span class="end"><b>desembarque estimado</b><span class="time">${i.end}</span></span>
                    <div class="time-for-voo">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="#fff" focusable="false" viewBox="0 0 32 32">
                            <path
                                d="M15.0369 17.8496C15.2231 17.7789 15.4235 17.8284 15.624 17.9839C15.7672 18.1182 15.8029 18.3019 15.7313 18.5352L13.7912 23.907L15.9389 23.3911C16.1251 23.3204 16.2397 23.2567 16.2826 23.1861L20.6497 15.9977C20.7428 15.8563 20.8358 15.7786 20.9289 15.7574L27.1717 13.5309C27.816 13.3047 28.2957 12.9796 28.6107 12.5555C28.9257 12.1314 28.9829 11.6719 28.804 11.1701C28.7539 11.0358 28.6823 10.8874 28.5749 10.7248C28.4675 10.5623 28.3028 10.4279 28.0737 10.3149C27.8446 10.2018 27.5153 10.1523 27.1001 10.1594C26.6849 10.1735 26.1336 10.2937 25.4392 10.5198L20.8287 12.1597C20.6926 12.2021 20.5494 12.2021 20.4134 12.1455C20.2774 12.089 20.1844 11.99 20.1342 11.8557C20.0841 11.7002 20.0984 11.5518 20.17 11.4246C20.2416 11.2973 20.3419 11.2125 20.485 11.1701L25.0955 9.53029C27.6156 8.6609 29.1834 9.09913 29.8134 10.8308C30.021 11.4034 30.0568 11.9193 29.9136 12.3858C29.7776 12.8523 29.4984 13.2694 29.0832 13.6369C28.668 14.0045 28.1453 14.3013 27.5225 14.5275L21.4873 16.6833L17.1847 23.7727C17.0487 24.0201 16.7193 24.2392 16.211 24.423L13.4046 25.0733C13.0753 25.144 12.839 25.0733 12.6744 24.8683C12.5097 24.6633 12.4811 24.423 12.567 24.1474L14.3353 19.2208L10.14 20.6627C8.98743 21.0515 7.90642 21.0868 6.89698 20.7617C5.88753 20.4436 5.11433 19.8004 4.55592 18.8462L2.16474 14.6689C1.84258 14.0751 1.99292 13.6652 2.61577 13.439L4.45568 12.7887C4.82795 12.6544 5.1716 12.711 5.49377 12.9584L8.78696 15.3898L12.9106 13.8843L7.67013 8.8164C7.51263 8.61142 7.44105 8.39229 7.46253 8.16611C7.53412 7.93993 7.68447 7.77736 7.91356 7.68548H7.94935L10.5839 6.96453C10.9061 6.85144 11.2283 6.88677 11.5504 7.07055L16.9985 10.018C17.1346 10.0887 17.2205 10.1947 17.2563 10.3431C17.292 10.4916 17.2706 10.6259 17.2061 10.739C17.1345 10.8732 17.0343 10.9651 16.8983 11.0146C16.7623 11.0641 16.6191 11.0499 16.483 10.9793L11.0349 8.00356C11.0135 7.98235 10.9705 7.98235 10.8989 8.00356L8.92298 8.5478L14.2923 13.7147C14.3425 13.7853 14.3783 13.8631 14.4141 13.955C14.4499 14.0469 14.457 14.1388 14.4355 14.2307C14.3854 14.4144 14.2781 14.5417 14.0919 14.6053L8.8872 16.4854C8.67958 16.5349 8.51493 16.5066 8.40038 16.4147L4.7993 13.7783L3.20283 14.3579L5.45798 18.2949C5.87321 19.0512 6.46024 19.5459 7.22627 19.7863C7.9923 20.0266 8.85856 19.9771 9.82504 19.6308L15.0369 17.8496Z">
                            </path>
                        </svg>
                        <span>${i.duration}</span>
                    </div>
                `

                div.onclick = function () {
                    ticketInfo(i.ticketId)
                }


                document.querySelector(".tickets-list").append(div)
            })




        })

}





function editTicket(ticket) {
    document.querySelector(".box-edit").style.display = "block"
    document.querySelector(".seat-edit").style.display = "none"

    console.log(ticket)
    document.querySelector(".buscar").onclick = function () {
        fetch('/findVoo/' + encodeURIComponent(ticket.origem) + "/" + encodeURIComponent(ticket.destino) + "/" + encodeURIComponent(document.querySelector(".box-edit #data").value))
            .then(response => response.json())
            .then(function (res) {
                document.querySelector(".box-edit .list").innerHTML = ""
                document.querySelector(".buscar").value = ""
                res.forEach(function (i) {
                    var div = document.createElement("div")
                    div.className = "item"
                    div.innerHTML = i.ida + "<b>" + i.start + "</b>";

                    div.onclick = function () {
                        fetch('/getseats/' + encodeURIComponent(i.id))
                            .then(response => response.json())
                            .then(function (res) {
                                document.querySelector(".seat-edit").style.display = "block"

                                gerarAssentos(document.querySelector(".seat-table-edit"), 50, res, ticket.ticketId, ticket.assento, function (newAssento) {
                                    var newIda = document.querySelector(".box-edit #data").value;

                                    fetch('/editTicket/' + encodeURIComponent(ticket.ticketId), {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify({
                                            assento: newAssento,
                                            ida: newIda
                                        })
                                    })
                                        .then(response => response.json())
                                        .then(function (res) {
                                            console.log(res)
                                            tickets()
                                        })


                                })
                            })
                    }

                    document.querySelector(".box-edit .list").append(div)
                })
            })
    }

}




// document.querySelector(".card").click()
// document.querySelector(".payment-end").click()
// setTimeout(function () {
//     document.querySelector(".tickets-list .item").click()
//     setTimeout(function () {
//         document.querySelector(".ticket-edit").click()
//         document.querySelector("#data").value = "25/05/2025"
//         document.querySelector(".buscar").click()    
//         setTimeout(function () {
//             document.querySelector(".box-edit .item").click()    
//         }, 500)



//     }, 200)

// }, 1000)







// adicionar 
// document.querySelector(".search").style.display = "block"



// setTimeout(function () {
//     clearLayout()
//     document.querySelector(".search").style.display = "block"
//     document.querySelector("#origem").value = "Cacheuta Spa, MDZ - Argentina"
//     document.querySelector("#destino").value = "Las Trancas, CCP - Chile"
//     document.querySelector("#ida").value = "01/01/2001"


//     document.querySelector(".search .submit").click()
//     setTimeout(function () {
//         document.querySelector(".search .item").click()
//         setTimeout(function () {
//             document.querySelector(".seat-table div[class=s]").click()
//             setTimeout(function () {
//                 document.querySelector(".payment-end").click()

//             }, 200)

//         }, 200)
//     }, 200)

// }, 200)





function getAssentos(id) {
    clearLayout()
    document.querySelector(".seat").style.display = "block";

    fetch('/getseats/' + encodeURIComponent(id))
        .then(response => response.json())
        .then(function (res) {
            gerarAssentos(document.querySelector(".seat-table"), 60, res, id, false, pagamento)
        })
}




function accountTT(el) {
    console.log(el)
    if(el.parentNode.querySelector(".account-tooltip").style.display == "none")
        el.parentNode.querySelector(".account-tooltip").style.display = "block";
    else
        el.parentNode.querySelector(".account-tooltip").style.display = "none";
}
// getAssentos("asc")



// gerarAssentos(document.querySelector(".seat-table-edit"), 50)




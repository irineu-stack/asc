


var db = {
    id: "LA158",
    origin: "GRU",
    destino: "SSA",
    start: "09:45",
    end: "16:45",
    duration: "2h 30min",
    price: 3000
}


// adicionar mais dados no banco de dados 
// for (let _ = 0; _ < array.length; _++) {
// }


exports.findVoo = function (origem, destino, ida) {
    db.origin = origem
    db.destino = destino
    db.ida = ida 

    return [db]
}